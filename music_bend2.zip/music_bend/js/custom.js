$(document).ready(()=>{
$(".hamburger").click(()=>{
    $("header nav").css("overflow","auto");
    $("header nav").css("height","100vh");
});
$(".close").click(()=>{
    $("header nav").css("overflow","hidden");
    $("header nav").css("height","0");
    
});


var cound_slider = 1;
$("#count_slider").html(cound_slider);

$(".right_arrow").click(()=>{

if(cound_slider == 1){
$(".caruesel .slide_1").fadeOut();
    setTimeout(function(){ $(".caruesel .slide_2").show()},390);
cound_slider = 2;
$("#count_slider").html(cound_slider);
$(".left_arrow").fadeIn();
}else if(cound_slider == 2){
    $(".caruesel .slide_2").fadeOut();
    setTimeout(function(){ $(".caruesel .slide_3").show()},390);
    cound_slider = 3;
    $("#count_slider").html(cound_slider);
}else if (cound_slider == 3) {
    $(".caruesel .slide_3").fadeOut();
    setTimeout(function(){ $(".caruesel .slide_1").show()},390);
    cound_slider = 1;
    $("#count_slider").html(cound_slider);
    $(".left_arrow").fadeOut();
}

})


$(".left_arrow").click(()=>{

    if(cound_slider == 2){
        $(".caruesel .slide_2").fadeOut();
        setTimeout(function(){ $(".caruesel .slide_1").show()},390);
        cound_slider = 1;
        $("#count_slider").html(cound_slider);
        $(".left_arrow").fadeOut();
    }else if (cound_slider == 3) {
        $(".caruesel .slide_3").fadeOut();
        setTimeout(function(){ $(".caruesel .slide_2").show()},390);
        cound_slider = 2;
        $("#count_slider").html(cound_slider);
    }
    
    })

    var col_slide = 1;
    $(".col_control_right").click(()=>{

        if (col_slide == 1) {
            $(".col_slides_1").css("height","0");
            $(".col_slides_2").css("height","75%");
            col_slide = 2
        }else if (col_slide == 2) {
            $(".col_slides_2").css("height","0");
            $(".col_slides_3").css("height","75%");
            col_slide = 3
        }else if (col_slide == 3) {
            $(".col_slides_3").css("height","0");
            $(".col_slides_1").css("height","75%");
            col_slide = 1
        }
    });

    $(".col_control_left").click(()=>{

        if (col_slide == 1) {
            $(".col_slides_1").css("height","0");
            $(".col_slides_3").css("height","75%");
            col_slide = 3
        }else if (col_slide == 2) {
            $(".col_slides_2").css("height","0");
            $(".col_slides_1").css("height","75%");
            col_slide = 1
        }else if (col_slide == 3) {
            $(".col_slides_3").css("height","0");
            $(".col_slides_2").css("height","75%");
            col_slide = 2
        }

        
    });

});





